/*
*	Licensed Materials - Property of IBM Corp.
*
*	Created by Tim Bula on 2016-02-22.
*	Copyright (c) 2016 IBM. All rights reserved. 
*	
*	U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
*	GSA ADP Schedule Contract with IBM Corp.
*
*	Author: Tim Bula
*	Plugin: Box Utilities
*	Filename: boxUploadFile.groovy
 */

import com.urbancode.air.AirPluginTool
import java.util.Map
import java.util.LinkedHashMap
import com.box.sdk.*
import org.bouncycastle.*
import org.bouncycastle.openssl.*
import com.eclipsesource.json.*
import org.jose4j.*
import java.io.File
import java.io.FileInputStream
import com.mobilefirst.box.*

def apTool = new AirPluginTool(this.args[0], this.args[1])
props = apTool.getStepProperties()
final def workDir = new File('.').canonicalFile

BoxFolder uploadFolder;

String appUserToken = props['app_user_token']

//generic
String folderName = props['folder']
//String file_path = props['file_path']
String fileName = props['file_name']

//ipa
String component = props['component']
//either from codestation or the build server?
String filePath = props['file_path']
String version = props['version']

//new connection to box using the dev token. Need to use the set property from the auth call in the future
System.out.println("auth_token: " + appUserToken);
BoxAPIConnection apiConnection = new BoxAPIConnection(appUserToken);

//get root folder
BoxFolder rootFolder = new BoxFolder.getRootFolder(apiConnection);

//searches the entire box account. Could change this to only search the root or 'app' folder
Iterable<BoxItem.Info> searchResults = rootFolder.search(folderName)
if (searchResults != null) {
	for (BoxItem.Info itemInfo : searchResults) {
		System.out.println(itemInfo.getInfo());
		if (itemInfo instanceof BoxFolder.Info && itemInfo.getName() == folderName) {
			uploadFolder = itemInfo.getResource()
		}
	}
} 
else {
	System.out.println("Not able to find matching folder. Creating folder on box");
	BoxFolder.Info uploadFolderInfo = rootFolder.createFolder(folderName);
	uploadFolder = uploadFolderInfo.getResource();
	System.out.println(uploadFolder.getInfo());
}

//file to upload
File file = new File(filePath);
fileName = (fileName == null || "".equals(fileName)) ? file.getName() : fileName; 
System.out.println("Uploading file: " + fileName);

//BoxAPIResponse response = new BoxAPIResponse();
//canUpload returns error if any of the preflight check fails
//try {
//	response = new_folder.canUploadTim(file_name, file.length()); 
//} catch(Exception e) {
//	System.err.println("Can't upload. API Error: " + e);
//}

// if (response.getResponseCode() == 200) {
// 	try {
// 		FileInputStream stream = new FileInputStream(file);
// 		BoxFile.Info uploaded_file_info = component_folder.uploadFile(stream, file_name); 
// 		stream.close();
// 		uploaded_file = uploaded_file_info.getResource();
// 		System.out.println("Uploaded file name: " + uploaded_file.getInfo().getName());
// 		System.out.println("Uploaded file id: " + uploaded_file.getInfo().getID());	

// 	} catch(Exception e) {
// 		System.err.println("Upload file unsuccessful: " + e);
// 	}
// } else {
// 	System.err.println("Pre flight check failed. Response code: " + response.getResponseCode());
// }

try {
	newFolder.canUpload(fileName, file.length());
	try {
		FileInputStream stream = new FileInputStream(file);
		BoxFile.Info uploadedFileInfo = newFolder.uploadFile(stream, fileName); 
		stream.close();
		uploadedFile = uploadedFileInfo.getResource();
		System.out.println("Uploaded file name: " + uploadedFile.getInfo().getName());
		System.out.println("Uploaded file id: " + uploadedFile.getInfo().getID());	
	} 
	catch (Exception e) {
		System.err.println("Uploading file failed. Exception: " + e.getMessage());
	}
}
catch (Exception e) {
	System.err.println("Prelfight check failed. Exception: " + e.getMessage());
}
