/*
*	Licensed Materials - Property of IBM Corp.
*
*	Created by Tim Bula on 2016-02-22.
*	Copyright (c) 2016 IBM. All rights reserved. 
*	
*	U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
*	GSA ADP Schedule Contract with IBM Corp.
*
*	Author: Tim Bula
*	Plugin: Box Utilities
*	Filename: boxSendAuthenticationCallAppUser.groovy
 */

import com.urbancode.air.AirPluginTool
import java.util.Map
import java.util.LinkedHashMap
import com.box.sdk.*
import org.bouncycastle.*
import org.bouncycastle.openssl.*
import com.eclipsesource.json.*
import org.jose4j.*
import java.io.File
import java.io.FileInputStream
import java.nio.file.Files;
import java.nio.file.Paths;
import org.slf4j.impl.*;
import org.slf4j.*;
import groovy.util.logging.Slf4j

def apTool = new AirPluginTool(this.args[0], this.args[1])
props = apTool.getStepProperties()
final def workDir = new File('.').canonicalFile

def appUserId = props['app_user_id']
def clientId = props['client_id']
def clientSecret = props['client_secret']
def publicKeyId = props['public_key_id']
def privateKey = props['private_key']
def privateKeyPath = props['private_key_path']
def privateKeyPassword = props['private_key_password']

System.out.println("appUserId: " + appUserId);
System.out.println("clientId: " + clientId);
System.out.println("clientSecret: " + clientSecret);
System.out.println("publicKeyId: " + publicKeyId);
System.out.println("privateKeyPath: " + privateKeyPath);
System.out.println("privateKeyPassword: " + privateKeyPassword);


//build up preferences for JWTAssertion
JWTEncryptionPreferences encryptionPreferences = new JWTEncryptionPreferences();
encryptionPreferences.setPublicKeyID(publicKeyId);
EncryptionAlgorithm encryptionAlgorithm = EncryptionAlgorithm.RSA_SHA_256;
encryptionPreferences.setEncryptionAlgorithm(encryptionAlgorithm);
//if the user doesn't set the private key, need the path to the file to be read in and parsed
if (privateKey == null || "".equals(privateKey)) {
	try {
        privateKey = new String(Files.readAllBytes(Paths.get(privateKeyPath)));
        System.out.println("privateKey: " + privateKey);
        encryptionPreferences.setPrivateKey(privateKey);
    } 
    catch (Exception e) {
        System.out.println("Reading private key error. Error message: " + e.getMessage());
        e.printStackTrace();
    }
} 
else {
    encryptionPreferences.setPrivateKey(privateKey);
}
encryptionPreferences.setPrivateKeyPassword(privateKeyPassword);

//User info needed for assertion
DeveloperEditionEntityType entityType = DeveloperEditionEntityType.USER;

//attempt creation of BoxDeveloperAPIConnection, bypassing manual UI interaction for authentication
//print out token for post processing capture and use in other scripts
try {
    BoxDeveloperEditionAPIConnection apiDevConnection = new BoxDeveloperEditionAPIConnection(appUserId, entityType, clientId, clientSecret, encryptionPreferences);
    String jwtAssertion = apiDevConnection.constructJWTAssertion();
	System.out.println(jwtAssertion);
    apiDevConnection.authenticate();
    String appUserToken = apiDevConnection.getAccessToken();
    System.out.println("app.user.auth.token:" + appUserToken);

} 
catch(Exception e) {
	System.err.println("Exception with JWT assertion. Error message: " + e.getMessage());
    e.printStackTrace();
}
